#!/usr/bin/perl
use feature qw/switch/;
use File::Basename;
use Getopt::Long qw(:config no_ignore_case bundling no_autoabbrev);
my $tag = '';	# option variable with default value


sub OSName {
# my $windows=($^O=~/Win/)?1:0;# Are we running on windows?
  if ($^O=~/Win/) {return "Win"};
  if ($^O=~/darwin/) {return "Mac"};
  if ($^O=~/linux/) {return "Linux"};
};

sub MakeSliceOutHash {
$par=$_[0];
my %myouthash = %$par;
$numstr=$_[1];
my %slicehash={}; 
foreach $keys (keys %myouthash) {
  $filename=$myouthash{$keys};
  ($name,$dir,$ext) = fileparse($filename,'\..*');
  $slicehash{$keys}=$dir.$name."_".$numstr.$ext;
};
return %slicehash;
};


sub MyExport {
$par=$_[0];
print "Myexport: \n";
%outputhash = %$par;
print "$_ $outputhash{$_}\n" for (keys %outputhash);
};


sub createoutputhash {
$par=$_[0];
print "par= $par"."\n";
@outputfmt = @$par;
print "formats= @outputfmt"."\n";
# = split /,+/, $_[0];
$basefilename = $_[1];
print "basefilename= $basefilename"."\n";
if ($basefilename eq "") {die "Error: no output base filename.";};
my %outputhash=(); # empty hash
foreach $format (@outputfmt) {
  print $format."\n";
 given ($format) {
  when(CIF) { 
     $outputhash{"CIF"}= $basefilename.".cif";
  }
  when("EMS") { 
     $outputhash{"EMS"}= $basefilename.".cel";
  }
  when("XMS") { 
     $outputhash{"XMS"}= $basefilename.".cel";
  }
  when("MT") { 
     $outputhash{"MT"}= $basefilename.".at";
  }
  when("VESTA") { 
     $outputhash{"CIF"}= $basefilename.".cif";
  }
  when("JSV") { 
     $outputhash{"JSV"}= $basefilename.".jsv";
  }
  when("VRML") { 
     $outputhash{"VRML"}= $basefilename.".wrl";
  }
  when("CM") { 
     $outputhash{"CIF"}= $basefilename.".cif";
  }
  when("ALI") { 
     $outputhash{"CMT"}= $basefilename.".cmt";
  }
  when("XYZ") { 
     $outputhash{"XYZ"}= $basefilename.".xyz";
  }
  default {}
} 
};
return %outputhash;
};

$Getopt::Long::autoabbrev=0;
$result=GetOptions ('cif' => \$cif, 'fmt|f=s' => \$writeformat, 'input|i=s' => \$inputfile, 'output|o=s' => \$outputfile);  
if  (!($inputfile)) {
die "Error: no input file given.\n"
  } else {
    ($name,$dir,$ext) = fileparse($inputfile,'\..*');
    $inputfile=$dir.$name.$ext
  };
if ((!($writeformat)) && ($outputfile)) {
  print "No output format given, choosing default XMS.\n";
  $writeformat .= ",XMS";
};
if ($cif) {
  # generating cif will work without output file specification
 $writeformat .= ",CIF";
};
# print "output format string: $writeformat"."\n";
@fmt = split /,/, $writeformat;
# print "output formats: @fmt"."\n";
$nformats=scalar @fmt;
print "number of formats: $nformats\n";
if ($outputfile) {
  # an output base name is given
  # check for a suffix
  # if only one 
  ($name,$dir,$ext) = fileparse($outputfile,'\..*');
} else {
  # no output file name given
  # construct a base name and append suffix 
  if  ($inputfile) {
    ($name,$dir,$ext) = fileparse($inputfile,'\..*');
  };
};
  $outputfilebase=$dir.$name;
  print "base filename: $outputfilebase"."\n";
  print "output formats: @fmt"."\n";
  if ($nformats > 0) {
    # more than one output format is selected
    # ignore the current extension and append suffix 
    %outhash=createoutputhash(\@fmt,$outputfilebase),
  };
print "$_ $outhash{$_}\n" for (keys %outhash);
# check whether there is a match between any of the output filenames and the input filename
foreach $keys (keys %outhash) {
# print "$outhash{$keys}"."\n";
  if ($outhash{$keys} eq $inputfile) {
    die "Error: Output filename matches input filename.\n";
  };
};
print "calling Export routine\n";
$hash_ref=\%outhash;
print $hash_ref."\n";
$num="001";
%slchash=MakeSliceOutHash($hash_ref,$num);
MyExport(\%slchash);
print OSName()."\n";

# create a heterointerface and write multiple output formats
CellMuncher --write-format=XMS,CIF,WRL --attach-cell=WSe2-2H-pureW.cel,XMS,z --in=MoS2-2H-pureMo.cel --out=superstructure.cel

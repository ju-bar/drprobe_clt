# create a facetted Au nanoparticle
# shift atoms to the centre ... there are 10 unit cells each, so the shift is 1/10/2=0.05
CellMuncher --override --prompt --repeat=x,10 --repeat=y,10 --repeat=z,10 --preview-file=VESTA --input-file=Au.cel --output-file=Au_times10.cel
# shift atoms to the centre ... there are 10 unit cells each, so the shift is 1/10/2=0.05
CellMuncher --override --prompt --translate-axis=x,0.05  --translate-axis=y,0.05  --translate-axis=z,0.05 --preview-file=VESTA --input-file=Au_times10.cel --output-file=tmp000.cel
# shift cell to origin 
CellMuncher --override --prompt --centre-at-zero --preview-file=VESTA --input-file=tmp000.cel --output-file=tmp001.cel
# cut outside 111 plane
CellMuncher --override --prompt --cut-above-plane=1,1,1,15 --delete-duplicate --preview-file=VESTA --input-file=tmp001.cel --output-file=tmp002.cel
# cut outside -1-1-1 plane
CellMuncher --override --prompt --cut-above-plane=-1,-1,-1,15 --delete-duplicate --preview-file=VESTA --input-file=tmp002.cel --output-file=tmp003.cel
# cut outside 11-1 plane
CellMuncher --override --prompt --cut-above-plane=1,1,-1,15 --delete-duplicate --preview-file=VESTA --input-file=tmp003.cel --output-file=tmp004.cel
# cut outside -1-11 plane
CellMuncher --override --prompt --cut-above-plane=-1,-1,1,15 --delete-duplicate --preview-file=VESTA --input-file=tmp004.cel --output-file=tmp005.cel
# cut outside 1-11 plane
CellMuncher --override --prompt --cut-above-plane=1,-1,1,15 --delete-duplicate --preview-file=VESTA --input-file=tmp005.cel --output-file=tmp006.cel
# cut outside -11-1 plane
CellMuncher --override --prompt --cut-above-plane=-1,1,-1,15 --prompt --preview-file=VESTA --input-file=tmp006.cel --output-file=tmp007.cel
# cut outside 1-1-1 plane
CellMuncher --override --prompt --cut-above-plane=1,-1,-1,15 --prompt --preview-file=VESTA --input-file=tmp007.cel --output-file=tmp008.cel
# cut outside -111 plane
CellMuncher --override --prompt --cut-above-plane=-1,1,1,15 --prompt --preview-file=VESTA --input-file=tmp008.cel --output-file=tmp009.cel
# cut outside 100 plane
CellMuncher --override --prompt --cut-above-plane=1,0,0,15 --prompt --preview-file=VESTA --input-file=tmp009.cel --output-file=tmp010.cel
# cut outside -100 plane
CellMuncher --override --prompt --cut-above-plane=-1,0,0,15 --prompt --preview-file=VESTA --input-file=tmp010.cel --output-file=tmp011.cel
# cut outside 010 plane
CellMuncher --override --prompt --cut-above-plane=0,1,0,15 --prompt --preview-file=VESTA --input-file=tmp011.cel --output-file=tmp012.cel
# cut outside 0-10 plane
CellMuncher --override --prompt --cut-above-plane=0,-1,0,15 --prompt --preview-file=VESTA --input-file=tmp012.cel --output-file=tmp013.cel
# cut outside 001 plane
CellMuncher --override --prompt --cut-above-plane=0,0,1,15 --prompt --preview-file=VESTA --input-file=tmp013.cel --output-file=tmp014.cel
# cut outside 00-1 plane
CellMuncher --override --prompt --cut-above-plane=0,0,-1,15 --prompt --preview-file=VESTA --input-file=tmp014.cel --output-file=tmp015.cel
#translate back
CellMuncher --debug --delete-duplicate 5 --override --prompt --translate-axis=x,0.5  --translate-axis=y,0.5  --translate-axis=z,0.5 --remove-close-atoms=0.1 --prompt --cif --input-file=tmp015.cel --output-file=Au-NP.cel
# delete temprorary files
rm tmp???.*

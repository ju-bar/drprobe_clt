# create a scre dislocation in Al2O3
# for a supercell-thickness of 5 nm
CellMuncher --read-format=MT --write-format=CIF --input-file=dis-cell23.at --output-file=test.CIF
CellMuncher --preview=VESTA --read-format=MT --input-file=dis-cell23.at --output-file=test.cel
CellMuncher --repeat=z,6 --preview=VESTA --input-file=test.cel --output-file=test3.cel
CellMuncher --mirror-axis=x,0.5 --preview=VESTA --input-file=test3.cel --output-file=test4.cel
CellMuncher --write-format=CIF --input-file=test4.cel --output-file=Supercell_no_dislocation.cif
CellMuncher --write-format=MT --input-file=test4.cel --output-file=Supercell_no_dislocation.at
CellMuncher --screw-dislocation=0.53561,0.48140,1.375,0. --input-file=test4.cel --output-file=test5.cel
CellMuncher --periodic=z --preview=VESTA --input-file=test5.cel --output-file=test6.cel
CellMuncher --write-format=CIF --input-file=test6.cel --output-file=Supercell_screw_dislocation.cif
CellMuncher --write-format=MT --input-file=test6.cel --output-file=Supercell_screw_dislocation.at

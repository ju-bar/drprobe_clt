# create a 3 nm spherical void in Ge
# repeat Ge unit cell 7 times in each direction
CellMuncher --override --repeat=x,7 --repeat=y,7 --repeat=z,7 --input-file=Ge.cel --output-file=tmp000.cel
# shift atoms to be centred around the origin at 0,0,0 
CellMuncher --override --centre-at-zero  --input-file=tmp000.cel --output-file=tmp001.cel
# cut inside radius of 15 A
CellMuncher --override  --cut-below-distance=xyz,15 --input-file=tmp001.cel --output-file=tmp002.cel
# translate cell so that coordinates are between 0 and 1
CellMuncher --cif --override --translate-axis=x,0.5  --translate-axis=y,0.5  --translate-axis=z,0.5 --cif --input-file=tmp002.cel --output-file=Ge-void.cel
# remove temporary files
rm tmp???.*

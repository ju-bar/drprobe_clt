#!/usr/bin/perl

sub DigitTo3CharString {
$a=@_[0];
# print STDERR "a=".$a." \n";
$out="";
if ($a < 100) {
    $out="0".$out;
    if ($a < 10) {
	$out="0".$out;
    };
};
$out=$out.$a;
return $out;
};


$nr=1;
while ($nr <= 230) {
print "		  SpaceGroup_$nr \=\> \{\n";
$data_file=DigitTo3CharString($nr).".txt";
open(DAT, $data_file) || die("Could not open file $data_file!\n");
$symcount=0;
while (<DAT>) {
  $line=$_;
  chomp($line);
  $line =~ s/^\s+//; # remove leading whitespace
  $line =~ s/\s+$//; # remove trailing whitespace
  if ($symcount == 0) {
    if ($line =~ /^Hermann\-Mauguin/) {
      @elem=split(/\:/,$line);
      $HM=$elem[1];
      $HM =~ s/^\s+//; # remove leading whitespace
      $HM =~ s/\s+$//; # remove trailing whitespace
      print "			  HermannMauguin \=\> \"$HM\"\,\n";
    };
    if ($line =~ /^Schoenflies\ symbol/) {
      @elem=split(/\:/,$line);
      $Schfl=$elem[1];
      $Schfl =~ s/^\s+//; # remove leading whitespace
      $Schfl =~ s/\s+$//; # remove trailing whitespace
      print "			  Schoenflies \=\> \"$Schfl\"\,\n";
    };
    if ($line =~ /^Hall\ symbol/) {
      @elem=split(/\:/,$line);
      $Hl=$elem[1];
      $Hl =~ s/^\s+//; # remove leading whitespace
      $Hl =~ s/\s+$//; # remove trailing whitespace
      $Hl =~ s/\"/\\\"/g;# replace " by protected \"
      print "			  Hall \=\> \"$Hl\"\,\n";
    };
    if ($line =~ /^Origin\ shift/) {
      # next line will be symop
      $symcount=1;
      print "			  SymOps \=\> \""
    };
  } else {
    # read a symmetry option
    if ($line) {
      @elem=split(/\ /,$line);
      if ($symcount > 1) {print " \: ";}; # add a ":" between the symopts
      print "$elem[0]";
      $symcount+=1;
    } else {
      $symcount=0;
      print "\"\,\n";
    };
  };
};
close(DAT);
print "		  \}\,\n";
$nr+=1;
};

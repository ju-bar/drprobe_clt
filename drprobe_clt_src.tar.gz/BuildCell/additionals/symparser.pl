#!/usr/bin/perl
use Getopt::Long qw(:config no_ignore_case bundling no_autoabbrev);


sub read_symmetry_db {
  my $spacegroupnr=@_[0];
  my %spacegroups=(  
		   # is a hash of hashes,
		   # space group Nr. => Herman Mauguin symbol, matrix symmetry operations 

		  '1' => {
			  HM => "P1",
			  SymOps => "x,y,z",
		  },
		  '2' => {
			  HM => "P-1",
			  SymOps => "x,y,z : -x,-y,-z",
		  },
		  '3' => {
			  HM => "P121",
			  SymOps => "x,y,z : -x,y,-z",
		  },
		  '4' => {
			  HM => "P12_11",
			  SymOps => "x,y,z : -x,y+1/2,-z",
		  },
		  '5' => {
			  HM => "C121",
			  SymOps => "x,y,z : -x,y,-z : x+1/2,y+1/2,z : -x+1/2,y+1/2,-z",
		  },
		  '6' => {
			  HM => "P1m1",
			  SymOps => "x,y,z : x,-y,z",
		  },
		  '7' => {
			  HM => "P1c1",
			  SymOps => "x,y,z : x,-y,z+1/2",
		  },
		  '8' => {
			  HM => "C1m1",
			  SymOps => "x,y,z : x,-y,z : x+1/2,y+1/2,z : x+1/2,-y+1/2,z",
		  },
		  '9' => {
			  HM => "C1c1",
			  SymOps => "x,y,z : x,-y,z+1/2 : x+1/2,y+1/2,z : x+1/2,-y+1/2,z+1/2",
		  },
		  '10' => {
			  HM => "P12/m1",
			  SymOps => "x,y,z : -x,y,-z : -x,-y,-z : x,-y,z",
		  },
		  '11' => {
			  HM => "P121/m1",
			  SymOps => "x,y,z : -x,y+1/2,-z : -x,-y,-z : x,-y-1/2,z",
		  },
		  '12' => {
			  HM => "C12/m1",
			  SymOps => "x,y,z : -x,y,-z : -x,-y,-z : x,-y,z : x+1/2,y+1/2,z : -x+1/2,y+1/2,-z : -x+1/2,-y+1/2,-z : x+1/2,-y+1/2,z",
		  },
		  '13' => {
			  HM => "P12/c1",
			  SymOps => "x,y,z : -x,y,-z+1/2 : -x,-y,-z : x,-y,z-1/2",
		  },
		  '14' => {
			  HM => "P121/c1",
			  SymOps => "x,y,z : -x,y+1/2,-z+1/2 : -x,-y,-z : x,-y-1/2,z-1/2",
		  },
		  '15' => {
			  HM => "C12/c1",
			  SymOps => "x,y,z : -x,y,-z+1/2  : -x,-y,-z : x,-y,z-1/2 : x+1/2,y+1/2,z : -x+1/2,y+1/2,-z+1/2 : -x+1/2,-y+1/2,-z : x+1/2,-y+1/2,z-1/2",
		  },
		  '16' => {
			  HM => "P 2 2 2",
			  SymOps => "x,y,z : -x,-y,z : x,-y,-z : -x,y,-z",
		  },
		  '17' => {
			  HM => "P 2 2 21",
			  SymOps => "x,y,z : -x,-y,z+1/2 : x,-y,-z : -x,y,-z+1/2",
		  },
		  '18' => {
			  HM => "P 21 21 2",
			  SymOps => "x,y,z : -x,-y,z : x+1/2,-y+1/2,-z : -x+1/2,y+1/2,-z",
		  },
		  '19' => {
			  HM => "P 21 21 21",
			  SymOps => "x,y,z : -x+1/2,-y,z+1/2 : x+1/2,-y+1/2,-z : -x,y+1/2,-z+1/2",
		  },
		  '20' => {
			  HM => "C 2 2 21",
			  SymOps => "x,y,z : -x,-y,z+1/2 : x,-y,-z : -x,y,-z+1/2 : x+1/2,y+1/2,z : -x+1/2,-y+1/2,z+1/2 : x+1/2,-y+1/2,-z : -x+1/2,y+1/2,-z+1/2",
		  },
		  '21' => {
			  HM => "C 2 2 2",
			  SymOps => "x,y,z : -x,-y,z : x,-y,-z : -x,y,-z : x+1/2,y+1/2,z : -x+1/2,-y+1/2,z : x+1/2,-y+1/2,-z : -x+1/2,y+1/2,-z ",
		  },
		  '22' => {
			  HM => "F 2 2 2",
			  SymOps => "x,y,z : -x,-y,z : x,-y,-z : -x,y,-z : x,y+1/2,z+1/2 : -x,-y+1/2,z+1/2 : x,-y+1/2,-z+1/2 : -x,y+1/2,-z+1/2 : x+1/2,y,z+1/2 : -x+1/2,-y,z+1/2 : x+1/2,-y,-z+1/2 : -x+1/2,y,-z+1/2 : x+1/2,y+1/2,z : -x+1/2,-y+1/2,z : x+1/2,-y+1/2,-z : -x+1/2,y+1/2,-z",
		  },
		  '23' => {
			  HM => "I 2 2 2",
			  SymOps => "x,y,z : -x,-y,z : x,-y,-z : -x,y,-z : x+1/2,y+1/2,z+1/2 : -x+1/2,-y+1/2,z+1/2 : x+1/2,-y+1/2,-z+1/2 : -x+1/2,y+1/2,-z+1/2",
		  },
		  '24' => {
			  HM => "I 21 21 21",
			  SymOps => "x,y,z : -x,-y+1/2,z : x,-y,-z+1/2 : -x,y+1/2,-z+1/2 : x+1/2,y+1/2,z+1/2 : -x+1/2,-y+1,z+1/2 : x+1/2,-y+1/2,-z+1 : -x+1/2,y+1,-z+1",
		  },
		  '25' => {
			  HM => "P m m 2",
			  SymOps => "x,y,z : -x,-y,z : -x,y,z : x,-y,z",
		  },
		  '26' => {
			  HM => "P m c 21",
			  SymOps => "x,y,z : -x,-y,z+1/2 : -x,y,z : x,-y,z+1/2",
		  },
		  '27' => {
			  HM => "P c c 2",
			  SymOps => "x,y,z : -x,-y,z : -x,y,z+1/2 : x,-y,z+1/2",
		  },
		  '28' => {
			  HM => "P m a 2",
			  SymOps => "x,y,z : -x,-y,z : -x+1/2,y,z : x+1/2,-y,z",
		  },
		  '29' => {
			  HM => "P c a 21",
			  SymOps => "x,y,z : -x,-y,z+1/2 : -x+1/2,y,z+1/2 : x+1/2,-y,z",
		  },
		  '30' => {
			  HM => "P n c 2",
			  SymOps => "x,y,z : -x,-y,z : -x,y+1/2,z+1/2 : x,-y+1/2,z+1/",
		  },
		  '31' => {
			  HM => "P m n 21",
			  SymOps => "x,y,z : -x+1/2,-y,z+1/2 : -x,y,z : x+1/2,-y,z+1/2",
		  },
		  '32' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '33' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '34' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '35' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '36' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '37' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '38' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '39' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '40' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '41' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '42' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '43' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '44' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '45' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '46' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '47' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '48' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '49' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '50' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '51' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '52' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '53' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '54' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '55' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '56' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '57' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '58' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '59' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '60' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '61' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '62' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '63' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '64' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '65' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '66' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '67' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '68' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '69' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '70' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '71' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '72' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '73' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '74' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '75' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '76' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '77' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '78' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '79' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '80' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '81' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '82' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '83' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '84' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '85' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '86' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '87' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '88' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '89' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '90' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '91' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '92' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '93' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '94' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '95' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '96' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '97' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '98' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '99' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '100' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '101' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '102' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '103' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '104' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		  '105' => {
			  HM => "",
			  SymOps => "x,y,z",
		  },
		   
		  );
  
};


sub parse_symmetry_string {
  # parameters: symmetry string
  my $s=@_[0]; # the symmetry string, e.g.: -y+1/2,x,z+1/2
  @matrix=([0.,0.,0.],[0.,0.,0.],[0.,0.,0.],[0.,0.,0.]); # symmetry peration in matrix form, the last vector is the translation in x,y,z
  lc $s; # convert to lower case 
  $s =~ s/ //g;  # remove whitespace from $s
  @symops=split(/,/,$s); # split to the three parts

  if (@symops < 3) {die("Fatal: Not enough symmetry operations in symmetry operator $s\n");};
  # parse for operators (+,-) and operands
  for ($i=0; $i<3; $i++) {
    # add a ":" before each operator
    $symops[$i] =~ s/\+/\:\+/g;
    $symops[$i] =~ s/\-/\:\-/g;
    @allop=split(/\:/,$symops[$i]);
    # print "$i @allop\n";
    foreach $op(@allop) {
      $op =~ s/ //g;  # remove whitespace from $op
      if ($op =~ m/x/) {
	if ($op =~ m/\-/) {
	  # print "$i matches -x\n";
	  $matrix[$i][0]=-1.
	} else { 
	  # print "$i matches +x\n";
	  $matrix[$i][0]=1.;
	};
      } else {
	if ($op =~ m/y/) {
	  if ($op =~ m/\-/) {
	    # print "$i matches -y\n";
	    $matrix[$i][1]=-1.
	  } else { 
	    # print "$i matches +y\n";
	    $matrix[$i][1]=1.;
	  };
	} else {
	  if ($op =~ m/z/) {
	    if ($op =~ m/\-/) {
	      # print "$i matches -z\n";
	      $matrix[$i][2]=-1.
	    } else { 
	      # print "$i matches +z\n";
	      $matrix[$i][2]=1.;
	    };
	  } else {
	    # it is a translation
	    # print "$i translation is ".eval($op)."\n";
	    $matrix[$i][3]=0.; 
	    if ($op) {$matrix[$i][3]=eval($op);}
	  };
	}; 
      };
    };
  };
  print "@{$matrix}";
  return $matrix;
};


sub set_spacegroup {
  my $ucell_ref=@_[0]; # reference to the unit cell hash
  my $spacegroupnr=@_[1];
  print "+ Setting spacegroup $spacegroupnr\n";
  $ucell_ref->{SpaceGroup}=$spacegroupnr;
};

sub set_lattice_parameters {
  my $ucell_ref=@_[0]; # reference to the unit cell hash
  my $latticepar=@_[1];
  $latticepar =~ s/ //g;  # remove whitespace from $s
  @lattice=split(/,/,$latticepar); # split to parts
  $lattice_ref=\@lattice;
  print "+ Setting lattice parameters $lattice_ref\n";
  $ucell_ref->{LatticeParameter}=$lattice_ref;
};

sub add_symmetry_operation {
  my $ucell_ref=@_[0]; # reference to the unit cell hash
  my $symop=@_[1];
  $symop =~ s/ //g;  # remove whitespace from $s
  print "+ Adding symmetry operation $symop\n";
  push @{$ucell_ref->{SymOp}}, $symop  ;
};


sub add_atom_to_basis {
  my $ucell_ref=@_[0]; # reference to the unit cell hash
  my $atom=@_[1];
  $atom =~ s/ //g;  # remove whitespace from $s
  @atomval=split(/,/,$atom); # split to parts
  foreach $val(@atomval) {
    $val=eval($val);
  };
  print "+ Adding base atom @atomval\n";
  push @{$ucell_ref->{Atom}}, [ @atomval ]  ;
};

sub create_primitive_cell {
  my $ucell_ref=@_[0]; # reference to the unit cell hash
  print "* Creating primitive cell\n";
  my @tmp=@ { $ucell_ref->{LatticeParameter}};
  $PrimitiveCell_ref={
		      SpaceGroup => 1,
		      LatticeParameter => \@tmp, # a, b, c, alpha, beta, gamma
		      Atom => (), # empty array of arrays
		     };
#  %$PrimitiveCell_ref{LatticeParameter}=@ { $ucell_ref->{LatticeParameter}};
  my @tmp=@ { $PrimitiveCell_ref->{LatticeParameter}};
  print "+ Primitive cell parameters @tmp\n";
  @symmetries=@{ $ucell_ref->{SymOp}};
  @atoms_in_basis=@{ $ucell_ref->{Atom}};
  $count=0;
  foreach my $sym (@symmetries) { 
    print "+ Applying symmetry operation $sym \n";
    $matrix=&parse_symmetry_string($sym);
    for($row = 0; $row < 3; $row++) {
      for($col = 0; $col < 4; $col++) {
	print "$matrix[$row][$col] ";
      };
      print "\n";
    };
    foreach my $atom (@atoms_in_basis) { 
      print "+ Applying matrix to atom @$atom \n";
      $symbol=$atom->[0];
      $dw=$atom->[5];
      $occ=$atom->[4];
      $fracx=$matrix[0][0]*$atom->[1]+$matrix[0][1]*$atom->[2]+$matrix[0][2]*$atom->[3]+$matrix[0][3];
      $fracy=$matrix[1][0]*$atom->[1]+$matrix[1][1]*$atom->[2]+$matrix[1][2]*$atom->[3]+$matrix[1][3];
      $fracz=$matrix[2][0]*$atom->[1]+$matrix[2][1]*$atom->[2]+$matrix[2][2]*$atom->[3]+$matrix[2][3];
      @v=($count,$symbol,$fracx,$fracy,$fracz,$dw,$occ);
      print "atom @v\n";
      push @{$PrimitiveCell_ref->{Atom}},  [ @v ];
      $count++;
    };  
    
  };
#
  return $PrimitiveCell_ref;
};


sub helpme{
# User needs help, here it is! 

    print "\nPrimitiveCell creates a unit cell\n";
    print "\nUSAGE: PrimitiveCell [OPTIONS]\n"; 
    print "\nOPTIONS:\n";
    print "\n--output, -o\n";
    print "     name of the .cel output file \n";
    print "--spacegroup, -s\n";
    print "     space group number\n";
    print "--lattice, -l\n";
    print "     lattice parameters (=a,b,c,alpha,beta,gamma)\n";
    print "--atom, -a\n";
    print "     atom (=symbol,x,y,z,occupancy,Debye-Waller-factor)\n";
    print "--symmetry, -y\n";
    print "     symmetry operator\n";
    print "\nEXAMPLE:\n";
    print "\nPrimitiveCell --spacegroup=194 --lattice=2.4642,2.4642,6.965,90.,90.,60. \n--atom=C,0.,0.,0.,1.0,0.5 --atom=C,1/3,1/3,0.,1.0,0.5  --output=graphene.cel\n\n‚";

  };

sub promptUser {

   #-------------------------------------------------------------------#
   #  two possible input arguments - $promptString, and $defaultValue  #
   #  make the input arguments local variables.                        #
   #-------------------------------------------------------------------#

   local($promptString,$defaultValue) = @_;

   #-------------------------------------------------------------------#
   #  if there is a default value, use the first print statement; if   #
   #  no default is provided, print the second string.                 #
   #-------------------------------------------------------------------#

   if ($defaultValue) {
      print $promptString, "[", $defaultValue, "]: ";
   } else {
      print $promptString, ": ";
   }

   $| = 1;               # force a flush after our print
   $_ = <STDIN>;         # get the input from STDIN (presumably the keyboard)


   #------------------------------------------------------------------#
   # remove the newline character from the end of the input the user  #
   # gave us.                                                         #
   #------------------------------------------------------------------#

   chomp;

   #-----------------------------------------------------------------#
   #  if we had a $default value, and the user gave us input, then   #
   #  return the input; if we had a default, and they gave us no     #
   #  no input, return the $defaultValue.                            #
   #                                                                 # 
   #  if we did not have a default value, then just return whatever  #
   #  the user gave us.  if they just hit the <enter> key,           #
   #  the calling routine will have to deal with that.               #
   #-----------------------------------------------------------------#

   if ("$defaultValue") {
      return $_ ? $_ : $defaultValue;    # return $_ if it has a value
   } else {
      return $_;
   }
}

sub PrintEMSData{
    $output=$_[0];
    $UnitCell_ref=$_[1];
    $accuracy=$_[2];
    @latticepar=@ { $UnitCell_ref->{LatticeParameter}};
    if ($accuracy == 0) {
	    print "% Writing EMS data.\n";
    }
    else {
	    print "% Writing EMS data with improved accuracy in atom positions.\n";
    }
    open FOUT, ">$output" or die "% Fatal error: can't open ".$output." for output";
    print FOUT "# Super-cell data created by PrimitiveCell \n";
    # MsRep : number of multislice repetions in ms
    $MsRep=0;    
    # absorption coefficients
    @abs=(0.0,0.0,0.0);
    # print cell data
    # check cell values gt than 100  
    # will be a problem for unformatted input
    if ($latticepar[0] >= 1000) {
      print "! Warning: a is greater than 100, problem with unformatted input!"
    };
    if ($latticepar[1] >= 1000) {
      print "! Warning: b is greater than 100, problem with unformatted input!"
    };
    if ($latticepar[2] >= 1000) {
      print "! Warning: c is greater than 100, problem with unformatted input!"
    };
    if ($latticepar[3] >= 100) {
      print "! Warning: alpha is greater than 100, problem with unformatted input!"
    };
    if ($latticepar[4] >= 100) {
      print "! Warning: beta is greater than 100, problem with unformatted input!"
    };
    if ($latticepar[5] >= 100) {
      print "! Warning: gamma is greater than 100, problem with unformatted input!"
    };
    #
    if ($accuracy == 0) {
	print FOUT " ".sprintf("%2d", $MsRep)." ".sprintf("%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f", $latticepar[0]/10, $latticepar[1]/10, $latticepar[2]/10, $latticepar[3], $latticepar[4], $latticepar[5]). "\n"; 
#	print $latticepar[0]." ".$latticepar[1]." ".$latticepar[2]." ".$latticepar[3]." ".$latticepar[4]." ".$latticepar[5]."\n";
    }
    else {
#	print FOUT " ".sprintf("%2d", $MsRep)." ".sprintf("%10.6f%10.6f%10.6f%10.6f%10.6f%10.6f", $latticepar[1]/10, $latticepar[2]/10, $latticepar[3]/10, $latticepar[4], $latticepar[5], $latticepar[6]). "\n";
	print FOUT " ".sprintf("%2d", $MsRep)." ".sprintf("%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f", $latticepar[0]/10, $latticepar[1]/10, $latticepar[2]/10, $latticepar[3], $latticepar[4], $latticepar[5]). "\n";
# 	print $latticepar[0]." ".$latticepar[1]." ".$latticepar[2]." ".$latticepar[3]." ".$latticepar[4]." ".$latticepar[5]."\n";
   };
    $a=$latticepar[0]; 
    $b=$latticepar[1];
    if ($b > $a) {
	print "% Warning: x-dim is smaller than y-dim, EMS will not accept\n          the output cell file, consider swapping the\n          x and y coordinate using the option -x xy.\n"
    };
    # now print FOUT all the atom coordinates
#     @v=($symbol,$fracx,$fracy,$fracz,$dw,$occ);
    @atoms=@{ $UnitCell_ref->{Atom}};
    foreach my $atom (@atoms) {
      @atomarr=@$atom;
      foreach $elem(@atomarr) {
	print "$elem ";
      };
      print "\n";
    };
    foreach my $atom(@atoms) { 
        # this ugly mess with $atom is only because a single character
        # atom must be padded to the right (uuuuugh) with a whitespace character
        # I hate these stupid Fortran lunatics ...
        # ... really ...
        # ... this costs time ...
      @atomarr=@$atom;
      @atchar=split //, $atomarr[0];
      if (scalar(@atchar) == 1) {
	$atsymbol = @atchar[0]." "
      }
      if ($accuracy == 0) {
	print FOUT " ".sprintf("%2s", $atsymbol)." ".sprintf("%8.4f%8.4f%8.4f%8.4f%8.4f", $atomarr[1], $atomarr[2], $atomarr[3], $atomarr[4],  $atomarr[5]/100).sprintf("%8.4f%8.4f%8.4f", $abs[0], $abs[1], $abs[2])."\n";
	}		
	else {
		print FOUT " ".sprintf("%2s", $atsymbol)." ".sprintf("%10.6f%10.6f%10.6f%10.6f%10.6f", $atomarr[1], $atomarr[2], $atomarr[3], $atomarr[4],  $atomarr[5]/100).sprintf("%10.6f%10.6f%10.6f", $abs[0], $abs[1], $abs[2])."\n";
	};	
    };
    print FOUT "*\n";
    close(FOUT);
};



$Getopt::Long::autoabbrev=0;
$help="";
$outputfile="";
$spacegroup=1;
$result = Getopt::Long::GetOptions ("help|h" => \$help, 
				    "output|o=s" => \$outputfile,
				    "spacegroup|s=s" => \$spacegroup,
				    "symmetry|y=s" => \@symmetries,
				    "atom|a=s" => \@atoms,
				    "lattice|l=s" => \$lattice,
				    "debug" => \$debug);  

if ($help) {&helpme; die "no valid input options found, stopping here \n";};

######################################################################################
## Check for output file 
######################################################################################
$out="";
if (!($outputfile)) {
    &helpme;
    die{"\nPlease specify a name for an output file with the --output or -o option\n"};
  } else {
    # check whether it exists already
    if ((-e $outputfile)) {
      if (!($override)) {
	$userresponse = &promptUser("Warning! Output file ".$outputfile." already exists, overwrite (y/n)");
	if ($userresponse eq 'y') {
	  $out=$outputfile;
	} else {
	  die "no output written\n";
	};
      } else {
	$out=$outputfile;
      };
    } else {
      $out=$outputfile;
    };
  };

######################################################################################

$UnitCell_ref={
	   SpaceGroup => 1,
	   LatticeParameter => (), # a, b, c, alpha, beta, gamma
	   SymOp => (), # empty array of scalar strings
	   Atom => (), # empty array of arrays
};


######################################################################################
## applying lattice parameters
## - option "--lattice|l" => \$lattice,
######################################################################################
if ($lattice) {
    if ($debug) {
      print "% Setting lattice parameters.\n";
    };
    &set_lattice_parameters($UnitCell_ref,$lattice);
};
######################################################################################
## reading atoms
## - option "--atom|a=s" => \@atoms,
######################################################################################
if (@atoms > 0) {
    if ($debug) {print "% Reading atoms.\n";};
    foreach $option (@atoms) {
      &add_atom_to_basis($UnitCell_ref,$option);
    };
}; 
######################################################################################
## applying spacegroup 
## - option "--spacegroup|s" => \$spacegroup,
######################################################################################
if ($spacegroup) {
    if ($debug) {
      print "% Adding spacegroup symmetries.\n";
    };
    &set_spacegroup($UnitCell_ref,$spacegroup);
};
######################################################################################
## reading symmetries
## - option "symmetry|y=s" => \@symmetries,
######################################################################################
if (@symmetries > 0) {
    if ($debug) {print "% Reading symmetries.\n";};
    foreach $option (@symmetries) {
      &add_symmetry_operation($UnitCell_ref,$option);
    };
}; 


###
print "* Input\n";
###
$spacegroupnr=194;
&set_spacegroup($UnitCell_ref,$spacegroupnr);
#
$lattice="2.4642,2.4642,6.965,90.,90.,60.";
&set_lattice_parameters($UnitCell_ref,$lattice);
#
$atom="C,0.,0.,0.,1.0,0.5";
&add_atom_to_basis($UnitCell_ref,$atom);
$atom="C,1/3,1/3,0.,1.0,0.5";
&add_atom_to_basis($UnitCell_ref,$atom);
#
$sym="x, y, z";
&add_symmetry_operation($UnitCell_ref,$sym);
$sym="-x+1/2, -y, z+1/2";
&add_symmetry_operation($UnitCell_ref,$sym);
$sym="-x+1/2, -y, z+1/2";
&add_symmetry_operation($UnitCell_ref,$sym);
#
###
print "* Output\n";
###
#foreach my $key (keys %$UnitCell_ref) { 
#print "$key = $UnitCell_ref->{$key}\n";
#};
print "$UnitCell_ref->{SpaceGroup}\n";
@latticepar=@ { $UnitCell_ref->{LatticeParameter}};
print "@latticepar\n";
@symmetries=@{ $UnitCell_ref->{SymOp}};
foreach my $sym (@symmetries) { 
  print "$sym \n";
};
#
@atoms_in_basis=@{ $UnitCell_ref->{Atom}};
foreach my $atom (@atoms_in_basis) { 
  print "@$atom \n";
};
#
print "* Matrix operations\n";
#
foreach $sym(@{ $UnitCell_ref->{SymOp}}) {
  print "$sym\n";
  $matrix=&parse_symmetry_string($sym);
  for($row = 0; $row < 3; $row++) {
    for($col = 0; $col < 4; $col++) {
      print "$matrix[$row][$col] ";
    }
    print "\n";
  };
}

$PrimCell=&create_primitive_cell($UnitCell_ref);

@atoms=@{ $UnitCell_ref->{Atom}};
foreach my $atom (@atoms) {
  @atomarr=@$atom;
  foreach $elem(@atomarr) {
    print "$elem ";
  };
  print "\n";
};
######################################################################################
## output of the cell data
######################################################################################
$rfilename=$rfilename.".cel"; 

PrintEMSData($out, $UnitCell_ref, 1);

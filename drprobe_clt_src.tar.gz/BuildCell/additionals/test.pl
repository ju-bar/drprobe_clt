#!/usr/bin/perl
use POSIX qw(ceil floor);

sub clean_string{
 $line=@_[0];
 chomp($line);
 $line =~ s/^\s+//; # remove leading whitespace
 $line =~ s/\s+$//; # remove trailing whitespace
 return $line;
};

sub parse_cif_string {
  $in_s=@_[0];
#  print "splitting $s?\n";
  $s=&clean_string($in_s);
  $space_is_separator=1;
  @chars=split(//,$s);
  @elements=();
  $k=0;
  $sub="";
  while ($k < @chars) {
#    print "$chars[$k]\n";  
    if ($chars[$k] =~ /\'/) {
      if ($space_is_separator == 1) {
	$space_is_separator = 0;
      } else {
	$space_is_separator = 1;
      };
    } else {
      if ($chars[$k] =~ /\s/) {
	# It  is a whitespace, what do we do? Split or continue?
	if  ($space_is_separator == 1) {
	  if ($sub ne "") {push(@elements,$sub);};
	  $sub="";
	};
      } else { 
	$sub=$sub.$chars[$k];
      };
      #      print "$sub\n";
    };
    $k++;
  }; 
  push(@elements,$sub);
  return @elements;
};

 my %spacegroups=(  
		   # is a hash of hashes,
		   # space group Nr. => Schoenflies symbol, Herman Mauguin symbol, Hall symbol, matrix symmetry operations 
		  SpaceGroup_1 => {
			  Schoenflies => "C1^1",
			  HermannMauguin => "P 1",
			  Hall => "P 1",
			  SymOps => "x,y,z",
		  },
		 );
$nr=1;
$key='SpaceGroup_'.$nr;
print "Searching hash for $key.\n";
print \%spacegroups."\n";
my $hash_ref=$spacegroups{$key};
my %hash=%$hash_ref;
print $hash{HermannMauguin}."\n";#->(HermannMauguin)
print $hash{SymOps}."\n";#->(HermannMauguin)
#
# 
print "* folding test\n";
$x=-0.567;
$y=$x - floor($x);
print "$x-floor($x) = $y\n";
print "* string split test\n";
$s="   1   'x-y, x, -z'";
print "$s\n";
@subs=&parse_cif_string($s);
foreach $elem(@subs) {
  print "$elem\n";
};

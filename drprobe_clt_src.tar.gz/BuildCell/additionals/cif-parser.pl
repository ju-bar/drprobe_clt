#!/usr/bin/perl
use Getopt::Long qw(:config no_ignore_case bundling no_autoabbrev);


sub clean_string{
 $line=@_[0];
 chomp($line);
 $line =~ s/^\s+//; # remove leading whitespace
 $line =~ s/\s+$//; # remove trailing whitespace
 return $line;
};

sub cif_clean_number {
# deletes brackets from number strings, e.g. 5.4423(3) -> 5.44233 
  $s=@_[0];
  $s =~ s/\(//;
  $s =~ s/\)//;
  return &clean_string($s);
}


sub cif_parse_string {
#
# splits a line in a cif file into an array of data fields
# e.g. "2 'x, y, -z+1/2'" -> ("2","x, y, -z+1/2")
# note that the space char is not strictly a separator
#
  $s=@_[0];
  $space_is_separator=1;
  @chars=split(//,$s);
  @elements=();
  my $k=0;
  $sub="";
  while ($k < @chars) {
#    print "$chars[$k]\n";  
    if ($chars[$k] =~ /\'/) {
      if ($space_is_separator == 1) {
	$space_is_separator = 0;
      } else {
	$space_is_separator = 1;
      };
    } else {
      if ($chars[$k] =~ /\ /) {
	# It  is a whitespace, what do we do? Split or continue?
	if  ($space_is_separator == 1) {
	  push(@elements,$sub);
	  $sub="";
	};
      }; 
      $sub=$sub.$chars[$k];
      #      print "$sub\n";
    };
    $k++;
  }; 
  push(@elements,$sub);
  return @elements;
};


sub clean_string{
 $line=@_[0];
 chomp($line);
 $line =~ s/^\s+//; # remove leading whitespace
 $line =~ s/\s+$//; # remove trailing whitespace
 return $line;
};



sub cif_parse_file {
#
# parser for a cif file
# analyzes the cif file and copies data into hash values
# 
$inputfile=@_[0];
# data hashes
#
# cfihash will contains single data
# each hash key is a single data name 
# add data names here if nessesary, they will be processed!
# 
%cifhash=(
	  '_database_code_ICSD' => 0.,
	  '_chemical_formula_structural' => "",
	  '_symmetry_Int_Tables_number' => 0.,
	  '_symmetry_space_group_name_H-M' => "",
	  '_cell_length_a' => 0.,
	  '_cell_length_b' => 0.,
	  '_cell_length_c' => 0.,
	  '_cell_angle_alpha' => 0.,
	  '_cell_angle_beta' => 0.,
	  '_cell_angle_gamma' => 0.,
	  
);
#
# loophash will contain column data in loop tables
# each hash key is a data name and a label to a column
# add data names here if nessesary, they will be processed!
# 
%loophash=(
	     '_symmetry_equiv_pos_as_xyz' => [],
	     '_atom_site_label' => [],
	     '_atom_site_fract_x' => [],
	     '_atom_site_fract_y' => [],
	     '_atom_site_fract_z' => [],
	     '_atom_site_occupancy' => [],
	     '_atom_site_U_iso_or_equiv' => [],

);
# start parsing
print "*******************\n";
print "* CIF parser      *\n";
print "*******************\n";
open(DAT, $inputfile) || die("Could not open file $data_file!\n");
@cifdata=<DAT>;
close(DAT);
$k=0;
$end=@cifdata;
while ($k < $end) {
  $line=$cifdata[$k];
  &clean_string($line);
  foreach $key(keys %cifhash) {
#    print "trying to match $line with $key\n";
    if ($line =~ /^$key/) {
      $line =~ s/$key//g;
      $cifhash{$key}=$line;
      # print "found match: $line\n";
    };    
  };
  if ($line =~ /^loop\_/) {
    print "--- loop ---\n";
    # first read the data names starting with a _xxx, and store their column position in a hash
    # then read the data lines into an array, the lines can be split into columns later
    # read data until there is either a '#' (comment), a "" (empty line) or a "_xxx" or a "loop_" specifier
    %loopdatanames=();
    @loopdata=();
    $k++;
    $line=$cifdata[$k];
    &clean_string($line);
    # first scan for the data names
    $n=0;
    while ((($line =~ /^\_/) && ($k < $end))) {
      # add data name to hash
      $loopdatanames{$line}=$n;
      $k++;
      $n++;
      $line=$cifdata[$k];
      &clean_string($line);
    };
    # some output
    print "data names: \n";
    while ( my ($key, $value) = each(%loopdatanames) ) {
      print "$key => $value\n";
    };
    # now scan for the data
    while (!(($line =~ /^\_/) || ($line =~ /^\#/) || ($line =~ /^loop\_/) || ($line eq "") || ($k == $end))) {
      push(@loopdata,$line);
      $k++;
      $line=$cifdata[$k];
      &clean_string($line);
    };
    print "data: \n";
    foreach $item(@loopdata) {
      print "$item\n";      
    };

    print "--- pool ---\n";
    $k--; # go back because we didn't process the line that terminates the loop
    #
    # analyze the loop data
    # search for each key in the hash %loophash
    # store the column data in the value to the key
    #
    for  my $searchkey ( keys %loophash )  {
      for  my $key( keys %loopdatanames ) {
#	print "comparing $key to $searchkey\n";
        if ($key =~ /$searchkey/) {
#	  print "matching data column for $key => $value\n";
	  $column=$loopdatanames{$key}; # the column in the loop data line
	  foreach $dataline(@loopdata) {
#	    # parse the string to an array
	    @arr=&cif_parse_string($dataline);
#	    print "$searchkey -> $arr[$column]\n";
	    push(@ { $loophash{$searchkey}},$arr[$column]);
	  };
	};
      };
    };
  };
  $k++;
};
print "*******************\n";
print "* CIF hashes output *\n";
print "*******************\n";
while ( my ($key, $value) = each(%cifhash) ) {
  print "$key => $value\n";
};
for  my  $key (keys %loophash)  {
  $tmp=$loophash{$key};
  print "$key => @$tmp\n";
};
 
};

$Getopt::Long::autoabbrev=0;
$help="";
$inputfile="";
$result = Getopt::Long::GetOptions ("help|h" => \$help, 
				    "cif|c=s" => \$inputfile,
				    "debug" => \$debug);  
if ($inputfile) {
  &parse_cif_file($inputfile)
};
